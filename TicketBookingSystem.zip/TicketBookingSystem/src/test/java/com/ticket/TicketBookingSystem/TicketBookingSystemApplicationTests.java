package com.ticket.TicketBookingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
